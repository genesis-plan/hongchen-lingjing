# 红尘灵境网页版

## 项目简介

红尘灵境是一款融合了修仙主题的学习管理应用，网页版版本提供更灵活的访问方式。

## 技术栈

- HTML5
- CSS3 (响应式设计)
- JavaScript (ES6+)
- 腾讯云云函数API (待集成)

## 功能特性

### 1. 落地页
- 精美的渐变背景设计
- 功能特性展示
- 进入应用引导

### 2. 主页（灵境）
- 用户信息展示
- 技能列表展示
- 快捷入口导航

### 3. 琅嬛藏书
- 知识内容浏览
- 搜索功能
- 分类展示

### 4. 修炼实训
- 实训项目列表
- 难度和时长标注
- 实训进度追踪

### 5. 荣誉殿堂
- 成就徽章展示
- 获得状态标识
- 激励系统

### 6. 个人空间
- 用户资料展示
- 统计数据
- 修行进度

## 文件结构

```
红尘灵境网页版/
├── index.html          # 主页面
├── styles.css          # 样式文件
├── app.js             # JavaScript逻辑
└── README.md          # 说明文档
```

## 快速开始

### 本地运行

1. 下载项目文件
2. 使用浏览器打开 `index.html`
3. 即可开始使用

### 在线部署

项目已准备就绪，可以部署到以下平台：

1. **腾讯云静态网站托管**
   - 使用我的API权限快速部署
   - 环境ID: hclj-8g46g9fd06e2a760
   - 已有部署地址: https://hclj-8g46g9fd06e2a760-1409755229.tcloudbaseapp.com

2. **GitHub Pages**
   - 推送到GitHub仓库
   - 启用GitHub Pages

3. **Netlify / Vercel**
   - 拖拽文件夹即可部署

## 使用说明

### 基本操作

1. **进入应用**: 点击"进入灵境"按钮
2. **页面切换**: 使用底部导航栏切换页面
3. **查看技能**: 点击技能卡片查看详情
4. **搜索内容**: 在琅嬛藏书页使用搜索框
5. **开始实训**: 点击实训项目开始练习

### 数据存储

- 用户数据存储在浏览器localStorage
- 刷新页面不会丢失数据
- 可清除浏览器数据重置

## 云函数集成（待开发）

当前版本使用模拟数据，后续将集成腾讯云云函数：

```javascript
// 示例：调用云函数
async function callCloudFunction(name, data) {
    const response = await fetch('/api/cloud-function', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name: name,
            data: data
        })
    });
    return response.json();
}
```

## 未来计划

### 短期目标
- [ ] 集成腾讯云云函数API
- [ ] 实现用户登录系统
- [ ] 数据库集成
- [ ] 实时数据同步

### 中期目标
- [ ] 社交功能
- [ ] AI助手集成
- [ ] 内容推荐系统
- [ ] 成就系统完善

### 长期目标
- [ ] 多端同步
- [ ] 个性化推荐
- [ ] 社区建设
- [ ] 内容生态

## 开发者信息

- **环境ID**: cloud1-6g38qqfz90d5e5d1
- **子账号SecretID**: YOUR_SECRET_ID_HERE
- **已有部署**: https://hclj-8g46g9fd06e2a760-1409755229.tcloudbaseapp.com

## 许可证

MIT License

## 联系方式

如有问题或建议，欢迎反馈。
